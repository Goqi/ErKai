package main

import (
	"CuiRi/core"
)

func main() {
	options := core.ParseOptions()
	core.Start(options)
}
