package constanta

const (
	PathNotFound     = "Path not found"
	FileNotFound     = "File not found"
	ExtRules         = ".yaml"
	RuleFileNotFound = "file not found in rules path"
	RulePathNotFOund = "rule path not found"
	MaxProcess       = 2
	RegexType        = "regex"
)
