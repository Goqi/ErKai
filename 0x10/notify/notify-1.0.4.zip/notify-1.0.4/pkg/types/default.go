package types

const (
	DefaultProviderConfigLocation = ".config/notify/provider-config.yaml"
)
