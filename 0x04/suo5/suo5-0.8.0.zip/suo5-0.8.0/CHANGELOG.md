# 更新记录

## [0.7.0] 2023-05-17

### 新增

- 增加 WebSphere 全版本支持
- 增加东方通（TongWeb）支持, 部分旧版需要禁用 gzip 才行
- 增加 `-no-gzip` 选项用于禁用响应中的 gzip 压缩
- 上游代理 `-proxy` 增加 http(s) 的支持，不再仅限于 socks5  [#23](https://github.com/zema1/suo5/issues/23) [#25](https://github.com/zema1/suo5/issues/25)
- 去除 Session 相关依赖，优化 stream 读写相关的代码, 有效解决部分能连上没数据的问题 [#22](https://github.com/zema1/suo5/issues/22)
- 增加代理自测试逻辑，如果没有报错那么代理一定可用
- 重写心跳包逻辑，如果 5s 内有数据读写，就不必发送心跳了
- 基础连接测试的逻辑融合到全双工的判断中，减少一个测试请求

### 修复
- 修复 GUI 版界面版本号错误的问题
- 暂时禁用 darwin 的内存占用显示

## [0.6.0] - 2023-04-10


### 新增

- 降低 JDK 依赖到 Java 4, 目前兼容 Java 4 ~ Java 19 全版本
- 新增 Tomcat Weblogic Resin Jetty 等中间件的自动化测试, 下列版本均测试通过:
    - Tomcat 4,5,6,7,8,9,10
    - Weblogic 10,12,14
    - Jboss 4,6
    - Jetty 9,10,11
- 更换一个更圆润的图标, 感谢 [@savior-only](https://github.com/savior-only)

### 修复

- 修复 GUI 版本在高版本 Edge 下启动缓慢的问题

## [0.5.0] - 2023-03-14

### 新增

- 每 5s 发送一个心跳包避免远端因 `ReadTimeout` 而关闭连接 [#12](https://github.com/zema1/suo5/issues/12)
- 改进地址检查方式，负载均衡的转发判断会更快一点

## [0.4.0] - 2023-03-05

### 新增

- 支持在负载均衡场景使用，需要通过 `-r` 指定一个 url，流量将集中到这个 url
- 支持自定义 header，而不仅仅是自定义 User-Agent [#5](https://github.com/zema1/suo5/issues/6)
- 优化连接控制，本地连接关闭后能更快的释放底层连接

### 修复

- 修复命令行版设置认证信息不生效的问题  [#5](https://github.com/zema1/suo5/issues/8)

## [0.3.0] - 2023-02-24

### 新增

- 支持自定义连接方法，如 GET, PATCH
- 支持配置上游代理, 仅支持 socks5
- 增加英文文档和变更记录

### 修复

- 修复部分英文语法错误

## [0.2.0] - 2023-02-22

### 新增

- 发布第一版本，包含 GUI 和 命令行版
- 使用 Github Action 自动构建所有版本的应用