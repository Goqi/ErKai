[主菜单](./cli.md)

### run        
运行shellcode，参数一为目标节点（可以为本机），参数二为shellcode代码(Base64或者Hex)或者本地文件，参数三为xor解密key,参数四为启动参数，参数五为shellcode运行等待时间
