package common
func ChangeArg(param string) {

	//linux暂不支持

}