//go:build linux || darwin
// +build linux darwin

package common

func ChangeArg(param string) {

	//linux暂不支持

}
