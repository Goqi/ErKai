package main

import "github.com/eatonchips/wsh/cmd"

func main() {
	cmd.Execute()
}
