---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

### Environment Data
* DeimosC2 Version:
* DeimosC2 Build:
* Operating System:

### Expected Behavior

### Actual Behavior

### Steps to Reproduce Behavior

### Misc Information
