// +build darwin

package shellinject

//ShellInject for Macos
func ShellInject(data string, process string) {
	//logging.Logger.Println("not implemented yed")
}
