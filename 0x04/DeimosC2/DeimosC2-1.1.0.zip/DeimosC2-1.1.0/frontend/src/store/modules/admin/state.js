export default {
  initialized: false,
  users: [],
  backupSettings: {
    days: [],
    hours: 0,
    minutes: 0
  },
  mfa: false,
  passlength: 16
};
