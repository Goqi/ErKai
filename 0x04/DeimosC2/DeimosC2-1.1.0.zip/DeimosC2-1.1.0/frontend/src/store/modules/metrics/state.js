export default {
  AgentTimeLine: {
    initialized: false,
    data: []
  },
  AgentOSType: {
    initialized: false,
    data: []
  },
  AgentByListener: {
    initialized: false,
    data: []
  },
  PivotGraph: {
    initialized: false,
    data: []
  }
};
