export default {
  loot: []
};
