export const AgentsByListenerSeries = state => Object.values(state.AgentByListener.data);

export default {
  AgentsByListenerSeries
};
