// type webShellPost struct {
//   URL       string
//   AuthToken string
//   Options   []string
// }

export default {
  initialized: false,
  types: ["PHP", "ASPX"],
  webShells: [],
  generatedShells: []
};
