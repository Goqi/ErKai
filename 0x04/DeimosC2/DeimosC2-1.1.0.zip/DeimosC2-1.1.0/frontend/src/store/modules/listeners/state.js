export default {
  initialized: false,
  settings: {},
  listeners: [],
  agents: []
};
