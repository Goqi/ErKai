cd frontend/
npm run build
cp -r dist/ ../resources/frontend/static/
cd ..
