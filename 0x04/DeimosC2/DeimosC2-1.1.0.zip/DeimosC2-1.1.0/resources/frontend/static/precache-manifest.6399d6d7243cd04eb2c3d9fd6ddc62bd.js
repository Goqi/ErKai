self.__precacheManifest = [
  {
    "revision": "35729cb7d540026265a7",
    "url": "/css/admin.77ace0e4.css"
  },
  {
    "revision": "35729cb7d540026265a7",
    "url": "/js/admin.87f110b8.js"
  },
  {
    "revision": "5c68cbf039cb7f4425d7",
    "url": "/css/app.28f166a4.css"
  },
  {
    "revision": "5c68cbf039cb7f4425d7",
    "url": "/js/app.116db66a.js"
  },
  {
    "revision": "29fc1f00f7b7682b9812",
    "url": "/css/chunk-74d1f821.e737219b.css"
  },
  {
    "revision": "29fc1f00f7b7682b9812",
    "url": "/js/chunk-74d1f821.a04f95cc.js"
  },
  {
    "revision": "5ed03eae9580d39cb006",
    "url": "/css/chunk-770eff66.92943c77.css"
  },
  {
    "revision": "5ed03eae9580d39cb006",
    "url": "/js/chunk-770eff66.84ebe2ce.js"
  },
  {
    "revision": "9867b82a3e8b0b7a8bdd",
    "url": "/css/chunk-vendors.61a9ac0d.css"
  },
  {
    "revision": "9867b82a3e8b0b7a8bdd",
    "url": "/js/chunk-vendors.ddd7fe08.js"
  },
  {
    "revision": "aeebcbd4cf7a74979dc8",
    "url": "/js/unauthorized.bb8f7e53.js"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "4a5d4d855d11fae79cc864bdacb2f479",
    "url": "/fonts/fa-brands-400.4a5d4d85.eot"
  },
  {
    "revision": "91a23e8bf2b4b84c39311cb5eb23aaa0",
    "url": "/fonts/fa-brands-400.91a23e8b.woff2"
  },
  {
    "revision": "4c1da237bdae0773309df93b2cd48e09",
    "url": "/fonts/fa-brands-400.4c1da237.ttf"
  },
  {
    "revision": "5734d789b25228cbafc64a58ae971aca",
    "url": "/fonts/fa-brands-400.5734d789.woff"
  },
  {
    "revision": "6b20949b3a679c30d09f64acd5d3317d",
    "url": "/fonts/fa-regular-400.6b20949b.eot"
  },
  {
    "revision": "5c674c9216c06ede2f618aa58ae71116",
    "url": "/fonts/fa-regular-400.5c674c92.woff2"
  },
  {
    "revision": "d44ad00c44e46fd29f6126fa7d888cde",
    "url": "/fonts/fa-regular-400.d44ad00c.woff"
  },
  {
    "revision": "260be4f29c0b2ce47480afb23f38f237",
    "url": "/fonts/fa-regular-400.260be4f2.ttf"
  },
  {
    "revision": "412a43d6840addd683665ec12c30f810",
    "url": "/fonts/fa-solid-900.412a43d6.woff2"
  },
  {
    "revision": "f3a7d3b5880544a91e9a7e6f8f35d4d2",
    "url": "/fonts/fa-solid-900.f3a7d3b5.woff"
  },
  {
    "revision": "9a1672a8a8d91fbf82c71f451d495253",
    "url": "/fonts/fa-solid-900.9a1672a8.eot"
  },
  {
    "revision": "c65d154888aa166982dac3e72e7380ec",
    "url": "/fonts/fa-solid-900.c65d1548.ttf"
  },
  {
    "revision": "66578cdbb6dc01f527a53971051b3e85",
    "url": "/img/fa-regular-400.66578cdb.svg"
  },
  {
    "revision": "778b1f251bea7412048da95b87bf816f",
    "url": "/img/fa-brands-400.778b1f25.svg"
  },
  {
    "revision": "486853107489520b3265b19b191626f8",
    "url": "/img/fa-solid-900.48685310.svg"
  },
  {
    "revision": "5987dd12fea78ce5f97ae601b08ec03c",
    "url": "/fonts/nucleo.5987dd12.woff2"
  },
  {
    "revision": "03ef1918e505c3e3471f9369ef7a638f",
    "url": "/fonts/nucleo.03ef1918.eot"
  },
  {
    "revision": "b17a118e13e53558658b681a0ebdad82",
    "url": "/fonts/nucleo.b17a118e.ttf"
  },
  {
    "revision": "f0b489a5dbbff08833d21024f9fcbd4e",
    "url": "/fonts/nucleo.f0b489a5.woff"
  },
  {
    "revision": "4e9592cdcbbbf7a0c610c754cb389fe1",
    "url": "/fonts/poppins-v9-latin-200.4e9592cd.woff2"
  },
  {
    "revision": "e8794816c5eaeaa9dd20a6d77ea3b272",
    "url": "/fonts/poppins-v9-latin-300.e8794816.woff2"
  },
  {
    "revision": "5c5aa25747e329a14d9ab8be881cbe02",
    "url": "/fonts/poppins-v9-latin-300.5c5aa257.woff"
  },
  {
    "revision": "1a280523d375e9358d5229df34fc8e94",
    "url": "/fonts/poppins-v9-latin-regular.1a280523.woff2"
  },
  {
    "revision": "7eef082fb93671877eff57d4ee4f3990",
    "url": "/fonts/poppins-v9-latin-200.7eef082f.woff"
  },
  {
    "revision": "61e2d96d01a7eba5ea3ec1bad7e736a8",
    "url": "/fonts/poppins-v9-latin-500.61e2d96d.woff2"
  },
  {
    "revision": "46a7d48240d428c9dc3d4ff579199312",
    "url": "/fonts/poppins-v9-latin-regular.46a7d482.woff"
  },
  {
    "revision": "aa4405ed937295296cf8510f437628e0",
    "url": "/fonts/poppins-v9-latin-600.aa4405ed.woff2"
  },
  {
    "revision": "1372de09cfc3e9a62af4234fd331e8e9",
    "url": "/fonts/poppins-v9-latin-500.1372de09.woff"
  },
  {
    "revision": "e535f7856b24153e0f3146e8f90a45c5",
    "url": "/fonts/poppins-v9-latin-700.e535f785.woff2"
  },
  {
    "revision": "bc1e47a3976358aa868a72de5a85de5a",
    "url": "/fonts/poppins-v9-latin-700.bc1e47a3.woff"
  },
  {
    "revision": "b5cd7d83a71851bd0d449c3cd5ddadfc",
    "url": "/fonts/poppins-v9-latin-800.b5cd7d83.woff2"
  },
  {
    "revision": "e3bbab8d37ba508809f78c4baf02ebdb",
    "url": "/fonts/poppins-v9-latin-600.e3bbab8d.woff"
  },
  {
    "revision": "bde99287fe27e0e3ee89058a0affd4cd",
    "url": "/fonts/poppins-v9-latin-800.bde99287.woff"
  },
  {
    "revision": "1067a661483d81d938d186ed828fc908",
    "url": "/index.html"
  },
  {
    "revision": "2a5a031c63d290c6cd3803e21d8c3b5d",
    "url": "/img/anime6.png"
  },
  {
    "revision": "3b91359dcf1cf96c8440a7532ac61dda",
    "url": "/img/anime3.png"
  },
  {
    "revision": "410af204d9a7b7a1659f0d3019aa9a3c",
    "url": "/favicon.png"
  },
  {
    "revision": "d2caaad36a395104bd99f30487798d79",
    "url": "/img/apple-icon.png"
  },
  {
    "revision": "d25412bcd9af1fb98017c8144a4e40d1",
    "url": "/img/default-avatar.png"
  },
  {
    "revision": "4422794dfa779751326660ae681b082e",
    "url": "/img/favicon.png"
  },
  {
    "revision": "fadc3f3a4c94b151d8b8ed33456c2344",
    "url": "/img/emilyz.jpg"
  },
  {
    "revision": "9b0c49b657dd738a77a37e7dabcc0b5d",
    "url": "/img/bg5.jpg"
  },
  {
    "revision": "40fdb6e1e72e21ff904da682c46d0116",
    "url": "/img/james.jpg"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/robots.txt"
  },
  {
    "revision": "93f1328bd264f02aacef8b0c6b498445",
    "url": "/img/mike.jpg"
  },
  {
    "revision": "f220d1815d421bfa192ee352780ba194",
    "url": "/img/img_3115.jpg"
  },
  {
    "revision": "4ed4c9f04050bbe97b314fdcfc67af30",
    "url": "/img/login-logo.png"
  }
];