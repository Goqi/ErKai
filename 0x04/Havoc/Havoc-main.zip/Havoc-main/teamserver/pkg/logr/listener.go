package logr

func (l Logr) ListenerAddKeyCert(Name, Key, Cert string) {

}
