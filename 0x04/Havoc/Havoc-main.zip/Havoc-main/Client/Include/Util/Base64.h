#ifndef HAVOC_BASE64_H
#define HAVOC_BASE64_H

#include <string>
#include <global.hpp>

std::string HavocNamespace::Util::base64_encode(const char* buf, unsigned int bufLen);

#endif
