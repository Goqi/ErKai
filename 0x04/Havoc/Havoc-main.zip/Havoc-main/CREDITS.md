# Credits

In this file i give credits to those people who helped me working on this project.

- [Austin Hudson](https://twitter.com/ilove2pwn_) 
    A lot of the code and ideas are based on his projects. Foliage is one of the sleep obfuscation techniques used by the havoc agent.

- [Bobby Cooke](https://twitter.com/0xBoku)
    A lot of techniques used are based on his projects. 

- [Codex](https://twitter.com/codex_tf2)
    Contributed and tested the C2 for flaws and bugs. 

- [Robert Musser](https://twitter.com/r_o_b_e_r_t_1)
    Contributed and tested the C2 for flaws and bugs. Added Docker support. 

- [Adam Svoboda](https://twitter.com/adamsvoboda)
    Contributed and tested the C2 for flaws and bugs. Worked on the wiki for the api, service and profiles. 

- [trickster0](https://twitter.com/trickster012)
    Contributed and tested the C2 for flaws and bugs.

- [Raul • theg3ntl3m4n](https://twitter.com/theg3ntl3m4n)
    Contributed and tested the C2 for flaws and bugs.

- [Zach Fleming](https://twitter.com/The___Undergrad)
    Contributed and tested the C2 for flaws and bugs.

- [Shawn (anthemtotheego)](https://twitter.com/anthemtotheego)
    Contributed and tested the C2 for flaws and bugs.

- [chbGSmCm](https://github.com/chbGSmCm)
    Contributed and tested the C2 for flaws and bugs.

- [Laith Yassin](https://twitter.com/LaithYassin13)
    Logo Designer.  

- [Fawaz - بوجابر](https://twitter.com/q8fawazo)
    Contributed and tested the C2 for flaws and bugs.

- [Giorgos Karantzas](https://twitter.com/GeKarantzas) & [Constantinos Patsakis](https://twitter.com/kpatsak) of University of Piraeus: 
    Various forms of generic\academic help during a past research engagement. Note: All experimentation took place prior to April 2022

- [@infosecnoodle](https://twitter.com/infosecnoodle)
  Designed session graph/table agent icons (with lighting bolt effects for high elevated targets)

