#include <Havoc/DBManager/DBManager.hpp>

using namespace HavocNamespace;
