#include <Havoc/Service.hpp>

uint64_t DemonMagicValue = 0xdeadbeef;
