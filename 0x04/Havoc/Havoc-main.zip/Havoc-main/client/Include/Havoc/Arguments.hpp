/*#include <boost/program_options.hpp>

class HavocArgOptions
{
public:
    boost::program_options::variables_map ArgumentsMap;

    HavocArgOptions(int argc, char** argv);

    bool GetBool(const std::string& flag) const;
    std::string GetString(const std::string& flag) const;
    int GetInteger(const std::string& flag) const;
};*/