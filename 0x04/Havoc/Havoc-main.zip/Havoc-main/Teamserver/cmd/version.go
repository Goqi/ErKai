package cmd

var (
	VersionNumber = "0.4.1"
	VersionName   = "The Fool"
)
