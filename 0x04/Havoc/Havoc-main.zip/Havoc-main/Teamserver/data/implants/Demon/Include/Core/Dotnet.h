#include <Common/Clr.h>

BOOL DotnetExecute( BUFFER Assembly, BUFFER Arguments );
VOID DotnetClose();
VOID DotnetPush();