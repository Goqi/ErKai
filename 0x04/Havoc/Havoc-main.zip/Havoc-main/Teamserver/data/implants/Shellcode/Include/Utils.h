#include <windows.h>

UINT_PTR HashString( LPVOID String, UINT_PTR Length );