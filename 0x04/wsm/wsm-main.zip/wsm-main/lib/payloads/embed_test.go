package payloads

import (
	"testing"
)

func Test_en(t *testing.T) {
	root := "F:\\gocode\\wsm\\lib\\payloads"
	err := getAllFile(root)
	if err != nil {
		return
	}
}
