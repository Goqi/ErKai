package entities

type System struct {
	DBModel
	SecretKey string
}
