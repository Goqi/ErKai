package constant

const (
	NoContent         = `No content.`
	TimeoutExceeded   = `Timeout exceeded.`
	TempDirectory     = `temp/`
	DatabaseDirectory = `database/`
)
