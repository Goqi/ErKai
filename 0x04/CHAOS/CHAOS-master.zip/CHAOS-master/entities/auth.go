package entities

type Auth struct {
	DBModel
	SecretKey string
}
