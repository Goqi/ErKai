This isn't an emp3r0r module, it serves static binaries only
