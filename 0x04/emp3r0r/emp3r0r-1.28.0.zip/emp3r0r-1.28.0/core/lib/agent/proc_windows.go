//go:build windows
// +build windows

package agent

func crossPlatformSetProcName(name string) {
	return
}
