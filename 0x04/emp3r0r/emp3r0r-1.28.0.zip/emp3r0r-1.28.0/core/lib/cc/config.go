package cc

import (
	emp3r0r_data "github.com/jm33-m0/emp3r0r/core/lib/data"
)

var RuntimeConfig = &emp3r0r_data.Config{}
