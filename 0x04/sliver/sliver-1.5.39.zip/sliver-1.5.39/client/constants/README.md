Constants
==========

A package of re-used strings and other constants
