Shell
======

Implements the interactive `shell` command.

