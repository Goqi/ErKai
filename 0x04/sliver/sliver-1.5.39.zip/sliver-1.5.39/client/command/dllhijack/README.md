DLL Hijack
===========

Implements command related to `dllhijack`.
