Info
====

Implements session information commands like `info`, `print`, `whoami`, etc.
