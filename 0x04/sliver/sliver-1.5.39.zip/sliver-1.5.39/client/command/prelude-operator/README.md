Prelude Operator
=================

Connection code for [Prelude Operator](https://www.prelude.org/)
