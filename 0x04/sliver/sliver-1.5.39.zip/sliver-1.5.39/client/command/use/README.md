Use
====

This package implements the `use` command, which is used to select active sessions/beacons.