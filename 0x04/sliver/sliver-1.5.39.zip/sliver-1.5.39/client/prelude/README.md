Prelude
=======

The `prelude` package handles the connection with [Prelude's Operator platform](https://www.prelude.org/).