package wininet

//go:generate go run ../tools/defines.go wininet /usr/x86_64-w64-mingw32/include/wininet.h
