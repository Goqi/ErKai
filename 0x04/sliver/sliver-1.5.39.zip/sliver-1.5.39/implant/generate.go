package implant

//go:generate ./scripts/update-vendor.sh
