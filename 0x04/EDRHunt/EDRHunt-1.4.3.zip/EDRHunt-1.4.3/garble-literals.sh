#!/usr/bin/env bash
garble -literals $@
