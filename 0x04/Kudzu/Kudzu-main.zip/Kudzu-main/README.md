# Kudzu
![Alt text](tmp/kudzu1.jpg?raw=true "Title")

Kudzu is a Go based C2 platform with an emphasis on extensibility. 
My goal was to provide a platform to which new scripts and exploits could be easily added and modified, and written in a modern language. 

It is a lofty goal, especially for a lone coder of dubious skill, but with enough time, determination, and caffeine, great things are possible!

Check out the docs for more info:
<a href="https://docs.kudzu.codes">here</a>


Find a bug? Have an idea for a feature? Need help tweaking scripts? Think this project is horrible? Let me know!

Twitter: @TerminalJockey

Email: TerminalJockey@protonmail.com

