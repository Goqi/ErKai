package chshare

//ProtocolVersion of chisel. When backwards
//incompatible changes are made, this will
//be incremented to signify a protocol
//mismatch.
const ProtocolVersion = "chisel-v3"

var BuildVersion = "0.0.0-src"
