package e2e_test

//TODO tests for:
// - SOCKS-client -> [client -> server SOCKS] -> endpoint
// - SOCKS-client -> [server -> client SOCKS] -> endpoint
