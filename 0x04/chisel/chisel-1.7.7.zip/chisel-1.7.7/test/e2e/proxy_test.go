package e2e_test

//TODO tests for:
// client -> CONNECT proxy -> server -> endpoint
// client -> SOCKS proxy -> server -> endpoint
