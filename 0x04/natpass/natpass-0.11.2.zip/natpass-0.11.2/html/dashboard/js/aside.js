var aside = {
    active_dashboard: function() {
        $('.sidebar #dashboard').addClass('active');
    },
    active_terminal: function() {
        $('.sidebar #terminal').addClass('active');
    },
    active_files: function() {
        $('.sidebar #files').addClass('active');
    }
};