package handler

import "errors"

var errNotHandshake = errors.New("not handshake")
var errInvalidHandshake = errors.New("invalid handshake")
