//go:build !windows
// +build !windows

package process

// CADEvent handle ctrl+alt+del event
func (p *Process) CADEvent() {
}
