package process

import "errors"

// ErrNotSupported not supported
var ErrNotSupported = errors.New("not supported")
