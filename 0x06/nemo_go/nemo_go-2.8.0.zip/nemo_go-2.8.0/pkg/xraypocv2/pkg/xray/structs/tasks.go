package structs

type Task struct {
	Poc    Poc
	Target string
}
