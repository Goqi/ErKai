---
name: Submit Template
about: Submit nuclei template using issue
title: "[nuclei-template] template-name"
labels: 'nuclei-template'
assignees: ''

---

**Template Details**

```yaml

nuclei template goes here
```
