# NOTES

## credit

- <https://github.com/EthanArbuckle/unredact-private-os_logs/pull/1>

### Usuage

Place profiles into the `/Library/Preferences/Logging/Subsystems` folder
