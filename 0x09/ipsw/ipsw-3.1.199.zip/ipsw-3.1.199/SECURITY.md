# Security Policy

## Supported Versions

Only the last stable version at any given point.

## Reporting a Vulnerability

Vulnerabilies can be disclosed via twitter to [@blacktop\_\_](https://twitter.com/blacktop__) or via keybase to [blacktop](https://keybase.io/blacktop).
