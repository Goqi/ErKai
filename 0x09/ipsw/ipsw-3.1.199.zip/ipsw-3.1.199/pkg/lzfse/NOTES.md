# NOTES

## src

- https://github.com/lzfse/lzfse

## Ideas

- https://github.com/minio/c2goasm
- https://github.com/minio/asm2plan9s
