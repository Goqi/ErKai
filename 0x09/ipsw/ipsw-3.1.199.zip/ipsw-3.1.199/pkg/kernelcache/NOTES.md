# NOTES

## Tagged Pointers

- https://bazad.github.io/2018/06/ios-12-kernelcache-tagged-pointers

## Sandbox

- https://github.com/malus-security/sandblaster
