package pbzx

type _Chunk struct {
	idx  int
	meta int
	data []byte
}
