# NOTES

- http://oid-info.com/cgi-bin/display?oid=1.2.840.113635.100.5.1&a=display
- https://opensource.apple.com/source/Security/Security-58286.41.2/trust/SecPolicyPriv.h.auto.html
