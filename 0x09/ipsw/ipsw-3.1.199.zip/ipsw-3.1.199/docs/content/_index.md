---
title: "ipsw"
date: 2020-01-25T21:02:49-05:00
---

Download and parse iOS ipsw(s)
