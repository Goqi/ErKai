---
title: "Overview"
date: 2020-01-25T21:15:23-05:00
draft: false
weight: 1
---

## **ipsw** isa:

- ipsw downloader/exploder
- macho parser
- dyld parser
- kernelcache parser
- device-tree parser
- ARM disassember
- research tool
- otool wannabe
- objdump wannabe
- jtool wannabe

---
