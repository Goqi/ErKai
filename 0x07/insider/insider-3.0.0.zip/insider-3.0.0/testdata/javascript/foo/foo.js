function main() {
    let password = "Super secret password";
    console.log(password);
}
