function main() {
    let password = "Super secret password";
    let email = "tmp@gmail.com"
    console.log(password);
    console.log(email);
}
