function insecure_function(a) {
    eval(a)
}


function secure_function(a) {
    console.log(a);
}

