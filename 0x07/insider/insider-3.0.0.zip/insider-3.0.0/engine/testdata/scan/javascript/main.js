function testing() {
    let password  = "secret";
    console.log(password);
}
