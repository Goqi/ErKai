<template>
    <div>
        eDefinder的项目贡献者如下所示<br>
        <a href="https://github.com/cjphaha/eDefender/graphs/contributors">
            <img src="https://contrib.rocks/image?repo=cjphaha/eDefender" />
        </a>
    </div>
</template>
