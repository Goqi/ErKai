## easy-project-templete

###  v0.0.1
> 1. base frame
> 2. plugins模块开发完成
> 3. 支持服务器状态检测

###  v1.0.0
> 1. 前端ok