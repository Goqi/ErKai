# BeeScan-scan (scan side)

## Introduction

Here is the scanning side of BeeScan. Based on the go language, it can realize efficient concurrent detection and greatly improve the efficiency of large-scale detection.

## how to use

Download the executable program of the corresponding platform of the release and run it.

The first run will generate the config.yaml configuration file, after which you need to modify the configuration, including the address and port of the database. The node name can then be customized. to prevent conflicts when there are multiple nodes.