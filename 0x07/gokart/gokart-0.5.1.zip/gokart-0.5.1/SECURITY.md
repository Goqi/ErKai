# GoKart Security Reporting Guidelines

To report a security issue, please email opensource@praetorian.com with a description of the issue, the steps you took to reproduce the issue, affected versions, and if known, mitigations for the issue. Our developers will acknowledge receiving your email within 3 working days. This project follows a 90 day disclosure timeline.
