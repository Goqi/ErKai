// Package standard implements the functionality for a non-headless crawler.
// It uses net/http for making requests and goquery for scraping web page HTML.
package standard
