#!/bin/sh

export GOPROXY=https://goproxy.cn
go mod tidy