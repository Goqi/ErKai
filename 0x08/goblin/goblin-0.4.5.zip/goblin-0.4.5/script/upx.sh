#!/bin/sh

upx dist/cloudtools_linux_amd64/cloudtools