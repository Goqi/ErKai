package inject

type InjectJs struct {
	EvilJs string `yaml:"File"`
}
