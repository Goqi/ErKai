package libgobuster

const (
	// VERSION contains the current gobuster version
	VERSION = "3.3"
)
