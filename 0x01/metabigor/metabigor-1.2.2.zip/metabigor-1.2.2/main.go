package main

import (
	"github.com/j3ssie/metabigor/cmd"
)

func main() {
	cmd.Execute()
}
