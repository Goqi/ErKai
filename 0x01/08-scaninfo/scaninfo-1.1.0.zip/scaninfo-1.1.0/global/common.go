package global

import "go.uber.org/zap"

var Log *zap.Logger
