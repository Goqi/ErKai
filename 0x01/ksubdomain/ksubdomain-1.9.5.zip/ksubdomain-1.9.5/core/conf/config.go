package conf

const (
	Version     = "1.9.5"
	AppName     = "KSubdomain"
	Description = "无状态子域名爆破工具"
)
