package result

type Result struct {
	Subdomain string
	Answers   []string
}
