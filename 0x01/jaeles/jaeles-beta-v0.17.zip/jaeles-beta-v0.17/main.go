package main

import "github.com/jaeles-project/jaeles/cmd"

func main() {
	cmd.Execute()
}
