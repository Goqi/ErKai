# Thanks

1. [Furious](https://github.com/liamg/furious) @liamg - Actual project from where the idea was taken.
2. [Nmap](https://nmap.org/) - For top port lists and being an amazing tool to infosec community.
3. [Masscan](https://github.com/robertdavidgraham/masscan) - Awesome and fast scanning tool
4. [Zmap](https://zmap.io/) - Highly optimized single port scan tool
