<h1 align="center">afrog</h1>
<p align="center">A Vulnerability Scanning Tools For Penetration Testing</p>

<p align="center" dir="auto">
  <a href="https://github.com/zan8in/afrog/releases">Download</a> •
  <!-- <a href="https://github.com/zan8in/afrog/blob/main/docs/GUIDE.md">指南</a> • -->
  <a href="https://github.com/zan8in/afrog/blob/main/docs/CONTRIBUTION.md">Contributors</a> •
  <a href="https://github.com/zan8in/afrog/tree/main/pocs/afrog-pocs">PoC</a>
  <!-- <a href="https://github.com/zan8in/afrog/blob/main/docs/POCLIST.md">列表</a> • -->
  <!-- <a href="https://github.com/zan8in/afrog/blob/main/docs/README_en.md">English Doc</a> -->
</p>

## PoC Contributors



<div><table frame=void>
	<tr>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/1.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="https://blog.csdn.net/U_U520"><sub>不动明王</sub></a>
        </td>    
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/2.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="https://www.linuxlz.com/"><sub>雪山</sub></a>
        </td> 
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/3.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="https://github.com/White-hua"><sub>White-hua</sub></a>
        </td> 
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/5.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="javascript:void(0)"><sub>123456</sub></a>
        </td> 
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/6.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="https://github.com/ifofor"><sub>ifofor</sub></a>
        </td> 
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/7.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="https://github.com/SkinAir"><sub>Air</sub></a>
        </td>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/8.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="https://github.com/zhizhuoshuma"><sub>执着</sub></a>
        </td>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/4.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="https://github.com/purple-WL"><sub>purple-WL</sub></a>
        </td>
	</tr>
    <tr>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/9.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="javascript:void(0);"><sub>throat</sub></a>
        </td>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/10.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="http://secx.store:4000/archives/"><sub>Secx</sub></a>
        </td>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/11.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="https://github.com/yueyu0740"><sub>冰河</sub></a>
        </td>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/12.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="javascript:void(0);"><sub>Sheen</sub></a>
        </td>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/13.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="javascript:void(0);"><sub>a16</sub></a>
        </td>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/14.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="javascript:void(0);"><sub>A1</sub></a>
        </td>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/15.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="https://github.com/rainbow2972"><sub>rainbow2972</sub></a>
        </td>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/16.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="https://github.com/wuha0926"><sub>wuha0926</sub></a>
        </td>
	</tr>	
    <tr>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/17.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="javascript:void(0);"><sub>茄子</sub></a>
        </td>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/18.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="javascript:void(0);"><sub>lei_sec</sub></a>
        </td>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/19.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="https://github.com/G-H-Z"><sub>G-H-Z</sub></a>
        </td>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/20.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="https://github.com/LDDP"><sub>wh1te</sub></a>
        </td>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/21.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="javascript:void(0);"><sub>清月</sub></a>
        </td>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/22.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="javascript:void(0);"><sub>york</sub></a>
        </td>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/23.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="javascript:void(0);"><sub>7eleven.eth</sub></a>
        </td>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/24.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="https://github.com/Double-q1015"><sub>Double-q1015</sub></a>
        </td>
    </tr>	
    <tr>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/25.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="https://github.com/iceyjchen"><sub>ICEY_</sub></a>
        </td>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/26.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="https://github.com/Ablackcatlazy"><sub>lazy</sub></a>
        </td>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/27.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="https://github.com/Lay0us1"><sub>Lay0us</sub></a>
        </td>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/28.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="javascript:void(0);"><sub>m4sk</sub></a>
        </td>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/29.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="https://www.yuque.com/chenmoshuren/qyxg2k"><sub>沉默树人</sub></a>
        </td>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/30.jpg"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="javascript:void(0);"><sub>陈麻子</sub></a>
        </td>
         <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/31.jpg"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="https://github.com/leonardo-o1"><sub>leonardo-o1</sub></a>
        </td>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/32.jpg"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="javascript:void(0);"><sub>江湖人称魏神</sub></a>
        </td>
    </tr>
    <tr>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/33.jpg"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="javascript:void(0);"><sub>若兮风</sub></a>
        </td>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/34.png"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="javascript:void(0);"><sub>-sudo</sub></a>
        </td>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/35.jpg"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="https://github.com/Cuerz"><sub>Cuerz</sub></a>
        </td>
        <td align="center">
            <img src="https://github.com/zan8in/afrog/blob/main/images/contributors/36.jpg"
                  alt="Typora-Logo"
                  height="80"/>
            <br>
            <a href="javascript:void(0);"><sub>laohuan12138</sub></a>
        </td>
    </tr>
</table></div>



## What is afrog

afrog is an excellent performance, fast and stable, PoC customizable vulnerability scanning (hole digging) tool. PoC involves CVE, CNVD, default password, information leakage, fingerprint identification, unauthorized access, arbitrary file reading, command execution, etc. It helps network security practitioners quickly verify and fix vulnerabilities in a timely manner.

## Features

* [x] Open Source
* [x] Fast, stable, low false positives
* [x] Detailed html vulnerability report
* [x] PoC can be customized and updated stably
* [x] Active community exchange group

## Example

Basic usage
```
# Scan a target
afrog -t http://127.0.0.1

# Scan multiple targets
afrog -T urls.txt

# Specify a scan report file
afrog -t http://127.0.0.1 -o result.html
```

Advanced usage

```
# Test PoC 
afrog -t http://127.0.0.1 -P ./test/ 
afrog -t http://127.0.0.1 -P ./test/demo.yaml 

# Scan by PoC Keywords 
afrog -t http://127.0.0.1 -s tomcat,springboot,shiro 

# Scan by PoC Vulnerability Severity Level 
afrog -t http://127.0.0.1 -S high,critical 

# Online update afrog-pocs 
afrog -up 

# Disable fingerprint recognition 
afrog -t http://127.0.0.1 -nf
```

## Screenshot

![](https://github.com/zan8in/afrog/blob/main/images/scan-new.png)

![](https://github.com/zan8in/afrog/blob/main/images/report-new.png)

## Discussion group

> For WeChat group, please add afrog personal account first, and remark "afrog", and then everyone will be pulled into the afrog communication group.

<img src="https://github.com/zan8in/afrog/blob/main/images/afrog.png" width="33%" />

## 404Starlink
<img src="https://github.com/knownsec/404StarLink-Project/raw/master/logo.png" width="30%">

afrog has joined [404Starlink](https://github.com/knownsec/404StarLink)

## Disclaimer

This tool is only for **legally authorized** enterprise security construction behavior. If you need to test the usability of this tool, please build a target environment by yourself.

In order to avoid malicious use, all PoCs included in this project are theoretical judgments of vulnerabilities, there is no vulnerability exploitation process, and no real attacks or exploits will be launched on the target.

When using this tool for detection, you should ensure that the behavior complies with local laws and regulations and has obtained sufficient authorization. **Do not scan unauthorized targets. **

If you have any illegal behavior in the process of using this tool, you shall bear the corresponding consequences by yourself, and we will not bear any legal and joint responsibility.

Before installing and using this tool, please **must read carefully and fully understand the contents of each clause**. Restrictions, disclaimers or other clauses involving your significant rights and interests may be bolded or underlined to remind you to pay attention . Unless you have fully read, fully understood and accepted all the terms of this agreement, please do not install and use this tool. Your use behavior or your acceptance of this agreement in any other express or implied manner shall be deemed that you have read and agreed to be bound by this agreement.