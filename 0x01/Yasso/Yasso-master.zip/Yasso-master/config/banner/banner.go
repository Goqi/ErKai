package banner

import (
	"fmt"
)

func Banner() {
	fmt.Println("_____.___.                         ____  ___\n\\__  |   |____    ______ __________\\   \\/  /\n /   |   \\__  \\  /  ___//  ___/  _ \\\\     / \n \\____   |/ __ \\_\\___ \\ \\___ (  <_> )     \\ \n / ______(____  /____  >____  >____/___/\\  \\\n \\/           \\/     \\/     \\/           \\_/")
	fmt.Println()
	fmt.Println("Refactoring version: Yasso v0.1.6")
	fmt.Println("法律免责声明:")
	fmt.Println("本工具仅面向合法授权的企业安全建设行为,如果需要测试本工具的可用性,请自行搭建靶场检测")
	fmt.Println("在使用本工具时,请确保你的操作符合当地的法律法规,并且获取到足够的授权,请勿对非授权目标使用")
	fmt.Println("使用本工具造成的非法行为,你需要自行承担后果,我们不受任何的法律及其连带责任,如果使用本工具,则视为接受本协议")
	fmt.Println("Github: github.com/sairson/Yasso")
}
