package main

import "Yasso/cmd"

func main() {
	cmd.Execute()
}
