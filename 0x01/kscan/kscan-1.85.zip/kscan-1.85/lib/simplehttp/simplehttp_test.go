package simplehttp

import "testing"

func TestGet(t *testing.T) {
	Get("https://14.215.177.39")
}
