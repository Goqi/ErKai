package gosmb

import "testing"

func TestName(t *testing.T) {
	_ = SmbGhostScan("192.168.50.11")
}
