package main

import (
	"github.com/s0md3v/smap/internal/core"
)

func main() {
	core.Init()
}
