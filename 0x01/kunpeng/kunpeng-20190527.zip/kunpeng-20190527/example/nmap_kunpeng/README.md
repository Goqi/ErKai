# Nmap 调用 kunpeng 示例

## 如何使用

1. 下载最新的 `kunpeng_c.so` 文件到当前目录

2. 安装 `nmap`

3. 安装 python 依赖库

```
$ pip install -r requirements.txt
```

4. 运行 `nmap_kunpeng.py` 即可

