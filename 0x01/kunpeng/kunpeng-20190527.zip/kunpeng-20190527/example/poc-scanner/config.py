#coding=utf-8

EXTRA_PATH = "./extra"
SO_PATH = "./so/kunpeng_c.so"

POC_SCANNER_USER = "admin"
POC_SCANNER_PWD_MD5 = "dd3d8c6062fac136f520cf39c39af267" # kunpeng@019

POC_HOST = "0.0.0.0"
POC_PORT = 12034
