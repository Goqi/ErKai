#coding=utf-8

from config import *
from tools.command import *

if __name__ == '__main__':
    runTornadoCommand(POC_HOST,POC_PORT)

