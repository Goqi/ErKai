package conf

/**
  @author: yhy
  @since: 2023/4/20
  @desc: //TODO
**/

var Proxy string
