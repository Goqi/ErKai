// Package stringz contains a set of utilities to deal with strings
package stringz
