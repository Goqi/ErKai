package fingerprint

import (
	_ "embed"
)

//go:embed dicts/eHoleFinger.json
var eHoleFinger string