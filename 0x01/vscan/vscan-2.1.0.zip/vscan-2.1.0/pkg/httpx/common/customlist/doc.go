// Package customlist contains all the funcionality to deal with Custom Target List
package customlist
