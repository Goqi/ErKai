package structs

import "github.com/projectdiscovery/nuclei/v2/pkg/templates"

type Poc = templates.Template
