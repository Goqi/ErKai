package lowsomething

import (
	"errors"
	"glint/logger"
	"glint/pkg/layers"
	"glint/plugin"
	"glint/util"
	"strings"

	"github.com/thoas/go-funk"
)

func Cookies_not_set_SameSite_flag(args interface{}) (*util.ScanResult, bool, error) {
	var err error
	var variations *util.Variations

	var CclassSomething ClassSomething
	//var hostid int64
	// var blastIters interface{}
	util.Setup()
	var Param layers.PluginParam
	// layers.Init()
	ct := layers.CheckType{}
	gd := args.(plugin.GroupData)
	Param.ParsePluginParams(args.(plugin.GroupData), ct)
	if Param.CheckForExitSignal() {
		return nil, false, errors.New("receive task exit signal")
	}
	sess, _ := Param.GenerateSession()
	if value, ok := Param.Headers["Content-Type"]; ok {
		Param.ContentType = value
	}
	variations, err = Param.GenerateVariable()

	//赋值
	CclassSomething.lastJob.Init(Param)
	CclassSomething.variations = variations
	CclassSomething.lastJob.Layer.Sess = sess
	CclassSomething.targetURL = Param.Url
	CclassSomething.lastJob.Layer.Method = Param.Method
	CclassSomething.lastJob.Layer.ContentType = Param.ContentType
	CclassSomething.lastJob.Layer.Headers = Param.Headers
	CclassSomething.lastJob.Layer.Body = []byte(Param.Body)

	if CclassSomething.startTesting456() {
		Result := util.VulnerableTcpOrUdpResult(Param.Url,
			"cookie not set SameSite  flag",
			[]string{string(CclassSomething.lastJob.Features.Request.String())},
			[]string{string(CclassSomething.lastJob.Features.Response.String())},
			"low",
			Param.Hostid, string(plugin.X_Frame_Options))
		gd.Alert(Result)
		return Result, true, err
	}
	return nil, false, errors.New("cookie not set Secure flag vulnerability not found")
}

func (c *ClassSomething) startTesting456() bool {
	///先请求一次
	_, response, err := c.lastJob.Layer.Sess.Get(c.targetURL, c.lastJob.Layer.Headers)
	//查看回复内容
	if err != nil {
		logger.Debug("plreq request error: %v", err)
		return false
	}
	cookies := response.Header.Peek("Set-Cookie")
	if len(cookies) == 0 {
		return false
	} else if !funk.Contains(strings.ToLower(string(cookies)), strings.ToLower("SameSite")) {
		return true
	}
	return false
}
