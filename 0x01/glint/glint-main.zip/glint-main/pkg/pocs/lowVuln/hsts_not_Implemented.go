package lowsomething

import (
	"errors"
	"glint/pkg/layers"
	"glint/plugin"
	"glint/util"
	"strings"
)

/**
title: HSTS Not Implemented
tags: HSTS
author: Alex
issue: 207
description:
    Alerts if HTTP Strict Transport Security (HSTS) is not implemented.
**/

func Hsts__Valid(args interface{}) (*util.ScanResult, bool, error) {
	var err error
	var variations *util.Variations

	var CclassSomething ClassSomething
	//var hostid int64
	// var blastIters interface{}
	util.Setup()
	var Param layers.PluginParam
	// layers.Init()
	ct := layers.CheckType{}
	gd := args.(plugin.GroupData)
	Param.ParsePluginParams(args.(plugin.GroupData), ct)
	if Param.CheckForExitSignal() {
		return nil, false, errors.New("receive task exit signal")
	}
	sess, _ := Param.GenerateSession()
	if value, ok := Param.Headers["Content-Type"]; ok {
		Param.ContentType = value
	}
	variations, err = Param.GenerateVariable()

	//赋值
	CclassSomething.lastJob.Init(Param)
	CclassSomething.variations = variations
	CclassSomething.lastJob.Layer.Sess = sess
	CclassSomething.targetURL = Param.Url
	CclassSomething.lastJob.Layer.Method = Param.Method
	CclassSomething.lastJob.Layer.ContentType = Param.ContentType
	CclassSomething.lastJob.Layer.Headers = Param.Headers
	CclassSomething.lastJob.Layer.Body = []byte(Param.Body)

	if CclassSomething.startTesting2() {
		Result := util.VulnerableTcpOrUdpResult(Param.Url,
			"HSTS Not Implemented",
			[]string{string(CclassSomething.lastJob.Features.Request.String())},
			[]string{string(CclassSomething.lastJob.Features.Response.String())},
			"low",
			Param.Hostid, string(plugin.X_Frame_Options))
		gd.Alert(Result)
		return Result, true, err
	}
	return nil, false, errors.New("HSTS Not Implemented vulnerability not found")
}

func (c *ClassSomething) startTesting2() bool {
	// _, resp, err := c.lastJob.Layer.Sess.Get(c.TargetUrl, c.lastJob.Layer.Headers)
	// if err != nil {
	// 	logger.Error("classSomething error %s", err.Error())
	// }
	// browser doesn't accept HSTS header via HTTP
	if strings.EqualFold(c.lastJob.Layer.ContentType, "text/html") {
		// HSTS headers are present?
		if value, ok := c.lastJob.Layer.Headers["Strict-Transport-Security"]; ok {
			hstsValue := value

			// __dbgout('hstsValue: ' + hstsValue);
			directives := strings.Split(hstsValue, ";")
			maxAge := false // greater or equal to 1 year
			//preload := false // not used
			iSD := false //include subdomains
			for _, d := range directives {
				// __dbgout('HSTS current directive: ' + d);
				curDir := strings.Split(d, "=")
				curName := strings.ToLower(strings.TrimSpace(curDir[0]))
				if curName == "includesubdomains" {
					iSD = true
				} else if curName == "preload" {
					//preload = true
				} else if curName == "max-age" {
					if curDir[1] != "" {
						maVal := strings.TrimSpace(curDir[1])
						maVal = strings.ReplaceAll(maVal, `"`, "")
						if len(maVal) >= 31536000 {
							maxAge = true
						}
					}
				}
			}

			if maxAge == false || iSD == false {
				//  __dbgout("alertImprovments maxAge=" + maxAge + ' iSD=' + iSD + ' at ' + scriptArg.http.request.uri);
				//alertImprovments(!maxAge, !iSD)
				return true
			}

		} else {
			// __dbgout("alertNoHSTS "+ scriptArg.http.request.uri);
			// alertNoHSTS()
			return false
		}
	}
	return false
}
