package weakpwd

import (
	"errors"
	"fmt"
	"glint/config"
	"glint/logger"
	"glint/nenet"
	"glint/pkg/layers"
	"glint/plugin"
	"glint/util"
	"strings"
	"time"
)

var passArray = []string{"pwd", "密码", "pass", "password", "passWord", "user_password", "user_pass", "user_pwd", "Password"}

var UserArray = []string{"user", "用户名", "username", "userName", "UserName", "user_name"}

var test1userPass = []string{"admin", "Liujadsv1997."}

var test2userPass = []string{"admin", "Liujadsv1998."}

type classWeakPwdAttack struct {
	scheme                 layers.Scheme
	TargetUrl              string
	inputIndex             int
	reflectionPoint        int
	disableSensorBased     bool
	currentVariation       int
	foundVulnOnVariation   bool
	variations             *util.Variations
	lastJob                layers.LastJob
	lastJobProof           interface{}
	scanningWAVSEP         bool
	scanningOwaspBenchmark bool
	isUnix                 bool
	isWindows              bool
	isJava                 bool
	isUnknown              bool
}

// type idxvar struct {
// 	idx int
// 	variable string
// }

func StartTesting(args interface{}) (*util.ScanResult, bool, error) {
	var err error
	var variations *util.Variations
	var WeakPwdAttack classWeakPwdAttack
	gd := args.(plugin.GroupData)
	//var hostid int64
	// var blastIters interface{}
	util.Setup()
	var Param layers.PluginParam
	// layers.Init()
	ct := layers.CheckType{IsMultipleUrls: false}
	Param.ParsePluginParams(args.(plugin.GroupData), ct)
	if Param.CheckForExitSignal() {
		return nil, false, errors.New("receive task exit signal")
	}

	sess := nenet.GetSessionByOptions(
		&nenet.ReqOptions{
			Timeout:       15 * time.Second,
			RetryTimes:    Param.MaxRedirectTimes,
			AllowRedirect: false,
			Proxy:         Param.UpProxy,
			Cert:          Param.Cert,
			PrivateKey:    Param.CertKey,
		})

	WeakPwdAttack.lastJob.Init(Param)
	// variations, err = util.ParseUri(url)
	// BlindSQL.variations =
	if value, ok := Param.Headers["Content-Type"]; ok {
		Param.ContentType = value
	}
	variations, err = util.ParseUri(Param.Url, []byte(Param.Body), Param.Method, Param.ContentType, Param.Headers)
	if err != nil {
		return nil, false, err
	}
	//赋值
	WeakPwdAttack.variations = variations
	WeakPwdAttack.lastJob.Layer.Sess = sess
	WeakPwdAttack.TargetUrl = Param.Url
	WeakPwdAttack.lastJob.Layer.Method = Param.Method
	WeakPwdAttack.lastJob.Layer.ContentType = Param.ContentType
	WeakPwdAttack.lastJob.Layer.Headers = Param.Headers
	WeakPwdAttack.lastJob.Layer.Body = []byte(Param.Body)

	var userpwdidx []layers.IdxVariable
	var is_user bool
	var is_password bool

	var userindexbyVarparam layers.IdxVariable //用户名的index
	var passindexbyVarparam layers.IdxVariable //密码的index

	for _, u := range UserArray {
		for _, vp := range variations.Params {
			if strings.EqualFold(vp.Name, u) {
				userindexbyVarparam.Idx = vp.Index
				userindexbyVarparam.Flag = "username"
				userpwdidx = append(userpwdidx, userindexbyVarparam)
				is_user = true
				// userpwdidx.
				break
			}
		}
	}

	for _, v := range passArray {
		for _, vp := range variations.Params {
			if strings.EqualFold(vp.Name, v) {
				passindexbyVarparam.Idx = vp.Index
				passindexbyVarparam.Flag = "password"
				userpwdidx = append(userpwdidx, passindexbyVarparam)
				is_password = true
				break
			}
		}
	}

	if !(is_user && is_password) {
		return nil, false, errors.New("not found user and password")
	}
	timeout := make(map[string]string)
	timeout["timeout"] = "3"

	var ERRORPWDFeatures layers.MFeatures
	//测试特征一

	userpwdidx[0].Variable = test1userPass[0] //设置用户名
	userpwdidx[1].Variable = test1userPass[1] //设置密码
	Features1, err := WeakPwdAttack.lastJob.RequestByIndexs(userpwdidx, Param.Url, timeout)

	userpwdidx[0].Variable = test2userPass[0] //设置用户名
	userpwdidx[1].Variable = test2userPass[1] //设置密码
	//测试特征二
	Features2, err := WeakPwdAttack.lastJob.RequestByIndexs(userpwdidx, Param.Url, timeout)

	if layers.CompareFeatures(&[]layers.MFeatures{Features1}, &[]layers.MFeatures{Features2}) {
		ERRORPWDFeatures = Features1
	}

	for _, username := range config.GlobalUserNameList {
		for _, password := range config.GlobalPasswordList {
			userpwdidx[0].Variable = username
			userpwdidx[1].Variable = password
			testFeatures, err := WeakPwdAttack.lastJob.RequestByIndexs(userpwdidx, Param.Url, timeout)
			if err != nil {
				logger.Error(err.Error())
			}
			if !layers.CompareFeatures(&[]layers.MFeatures{testFeatures}, &[]layers.MFeatures{ERRORPWDFeatures}) {
				//都测试完成后，可以断定这个站点没有对密码长度进行限制。
				output := fmt.Sprintf("weak passwd denial of service userName:%s password:%s", username, password)
				Result := util.VulnerableTcpOrUdpResult(Param.Url,
					output,
					[]string{string(testFeatures.Request.String())},
					[]string{string(testFeatures.Response.String())},
					"high",
					Param.Hostid, string(plugin.WeakPwdAttack))
				gd.Alert(Result)
				return Result, true, err
			}
		}
	}

	return nil, false, err
}
