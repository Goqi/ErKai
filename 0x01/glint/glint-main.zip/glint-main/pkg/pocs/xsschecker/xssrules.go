package xsschecker

//此包专门针对xss更具上下文设置payload，智能化的框架

//有些人为的过滤是可以用代码敲出来的
//例如专门针对  data.replace(替换关键字,"")
//有些是只能依靠ai生成智能的payload
