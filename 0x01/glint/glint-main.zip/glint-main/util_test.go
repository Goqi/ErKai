package main

import (
	"encoding/base64"
	"fmt"
	"glint/crawler"
	"glint/logger"
	"glint/util"
	"io/ioutil"
	"os"
	"regexp"
	"strings"
	"testing"
	"time"
	"unsafe"
)

func Test_Post(t *testing.T) {
	body := "file=123456.fkuior.ceye.io&read=load+file"
	param, _ := util.ParseUri("", []byte(body), "POST", "application/x-www-form-urlencoded", nil)
	logger.Debug("%v", param)
	pal := param.SetPayload("", "122", "POST")
	logger.Debug("%v", pal)
	//Get
	param1, _ := util.ParseUri("https://www.google.com/search?q=dasdas&oq=dasdas", []byte(""), "GET", "None", nil)
	logger.Debug("%v", param1)
	pal1 := param1.SetPayload("https://www.google.com/search?q=dasdas&oq=dasdas", "122", "GET")
	logger.Debug("%v", pal1)
}

func Test_For(t *testing.T) {
	for i := 0; i < 2; i++ {
		fmt.Printf("%d", i)
	}
}

func Test_Regex(t *testing.T) {
	var tsr = `我的邮箱 ljl260435988@gmail.com`
	var regexemails = `(?i)([_a-z\d\-\.]+@([_a-z\d\-]+(\.[a-z]+)+))`
	re, _ := regexp.Compile(regexemails)
	result := re.FindString(tsr)
	fmt.Println(result)

	var tsrs = `192.168.166.16 192.168.166.7`
	regexIp := `\b(192\.168\.(?:[0-9]{1,2}|[01][0-9]{2}|2(?:[0-4][0-9]|5[0-5]))\.(?:[0-9]{1,2}|[01][0-9]{2}|2(?:[0-4][0-9]|5[0-5]))|172\.(?:16|17|18|19|(?:2[0-9])|30|31)\.(?:[0-9]{1,2}|[01][0-9]{2}|2(?:[0-4][0-9]|5[0-5]))\.(?:[0-9]{1,2}|[01][0-9]{2}|2(?:[0-4][0-9]|5[0-5]))|10\.(?:[0-9]{1,2}|[01][0-9]{2}|2(?:[0-4][0-9]|5[0-5]))\.(?:[0-9]{1,2}|[01][0-9]{2}|2(?:[0-4][0-9]|5[0-5]))\.(?:[0-9]{1,2}|[01][0-9]{2}|2(?:[0-4][0-9]|5[0-5])))\b`
	RE, _ := regexp.Compile(regexIp)
	ips := RE.FindAllString(tsrs, -1)
	fmt.Println(ips)

	var tsrss = `"Db_user"="1221"
	"Db_pass"='20sdasdasd'`
	regexx := `(?i)(?m)(['"]?(db[\-_])?(uid|user|username)['"]?\s?(:|=)\s*['"]?([A-Za-z0-9_\-@$!%*#?&]){3,}['"]?[,]?([\r\n]+)\s*['"]?(db[\-_])?(pass|pwd|passwd|password)['"]?\s?(:|=)\s*['"]?([A-Za-z0-9_\-@$!%*#?&]){6,}['"]?([,\r\n]|$))`
	RE1, _ := regexp.Compile(regexx)
	m := RE1.FindAllString(tsrss, -1)
	fmt.Println(m)

	tsrsss := "/cn/about\r\n\r\r\n   "
	r := regexp.MustCompile(`(\r|\n|\s+)`)
	_url := r.ReplaceAllString(tsrsss, "")
	fmt.Println(_url)

}

func Test_Rate(t *testing.T) {
	//测试每秒发送10个链接,测试10秒
	myRate := util.Rate{}
	// bShutdown := make(chan bool)
	myRate.InitRate(20)
	for i := 0; i < 100; i++ {
		go func(r *util.Rate, i int) {
			logger.Info("Start id:%d", i)
			r.LimitWait()
			if i == 99 {
				logger.Info("End id:%d Get Current Count: %d", i, r.GetIndex())
			}
		}(&myRate, i)
	}
	time.Sleep(time.Second * 20)
}

func Test_Ts(t *testing.T) {
	nm := util.NetworkManager{}
	arrays := unsafe.Sizeof(nm)
	// consumeGb := 1073741824
	// Count := consumeGb / arrays
	fmt.Println(arrays) // 8
}

func Test_AES_CBC_SHA256(t *testing.T) {
	ccc := "<script>var div=document.createElement('div');div.innerText = 'ab49bdd251591b16da'+'541abad631329c';document.body.appendChild(div);</script>"
	fmt.Println(len(ccc))
	orig := "hello world"
	key := "web2.0_password0"
	fmt.Println("原文：", orig)
	encryptCode := util.AesEncrypt(orig, key)
	fmt.Println("密文：", encryptCode)
	decryptCode := util.AesDecrypt(encryptCode, key)
	fmt.Println("解密结果：", decryptCode)
	fp, err := os.OpenFile("test64.txt", os.O_RDWR|os.O_CREATE|os.O_TRUNC, 0755)
	if err != nil {
		logger.Fatal("%s", err.Error())
	}
	defer fp.Close()
	_, err = fp.Write([]byte(encryptCode))
	if err != nil {
		logger.Fatal("%s", err.Error())
	}
}

func Test_runFunc(t *testing.T) {
	s := "https://www.google.com/search/dsadsad?q=dasdas&oq=dasdas"
	//解析这个 URL 并确保解析没有出错。
	fmt.Println(util.GetScanDeepByUrl(s))

	rule1 := strings.Replace(s, "http://", "https://", -1)
	println(rule1)
	rule2 := strings.Replace(s, "https://", "http://", -1)
	println(rule2)
}

func Test_base64_encode(t *testing.T) {

	// fp, err := os.OpenFile("wvsc_blob.bin", os.O_RDWR|os.O_CREATE|os.O_TRUNC, 0755)
	file, err := os.Open("wvsc_blob.bin")
	if err != nil {
		panic(err)
	}
	defer file.Close()
	content, err := ioutil.ReadAll(file)
	// fp.Read()

	encryptCode := base64.StdEncoding.EncodeToString(content)

	fp, err := os.OpenFile("wvsc_blob.base64", os.O_RDWR|os.O_CREATE|os.O_TRUNC, 0755)
	if err != nil {
		logger.Fatal("%s", err.Error())
	}
	defer fp.Close()
	_, err = fp.Write([]byte(encryptCode))
	if err != nil {
		logger.Fatal("%s", err.Error())
	}
}

func Test_base64_decode(t *testing.T) {

	// fp, err := os.OpenFile("wvsc_blob.bin", os.O_RDWR|os.O_CREATE|os.O_TRUNC, 0755)

	// fp.Read()

	decryptArray, err := base64.StdEncoding.DecodeString("PCUgUmVzcG9uc2UuV3JpdGUoIjRkMDIwNzBlZmZkZDdlMzE5IiArICJjYTU2MWJjNjY2MTdhOGEiKSAlPg==")
	if err != nil {
		t.Fatalf("%s", err.Error())
	}
	fmt.Println(string(decryptArray))
}

func Test_GenVclock(t *testing.T) {
	err := util.GenerateVlockFile(30000)
	if err != nil {
		panic(err)
	}
}

func Test_GetFileNameFromUrl(t *testing.T) {
	ts1 := "http://localhost/slow/1222.json"
	filename, err := util.GetFileNameFromUrl(ts1)
	if err != nil {
		t.Fatalf("%s", err.Error())
	}
	fmt.Println(string(filename))
}

func Test_url_parse(t *testing.T) {
	//ListURLPath 此变量具有继承效应
	// var ListURLPath []string
	var SiteRootNode crawler.SiteRootNode

	s := "http://api.themoviedb.org/3/tv/3"

	SiteRootNode.ADD_NODE(s)

	// SiteRootNode

	ss := "http://api.themoviedb.org/3/451"

	SiteRootNode.ADD_NODE(ss)

	fmt.Println(SiteRootNode)

}
