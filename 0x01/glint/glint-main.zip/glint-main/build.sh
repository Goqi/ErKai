go build
chmod +x ./glint
mv glint /usr/local/863/bin/glint