package main

import "github.com/j3ssie/osmedeus/cmd"

func main() {
	cmd.Execute()
}
