package execution

//
//func TestCleanWebanalyze(t *testing.T) {
//	var options libs.Options
//	options.Debug = true
//	CleanWebanalyze("/Users/j3ssie/.osmedeus/workspaces/duckduckgo.com/fingerprint/duckduckgo.com-technology.json", "/Users/j3ssie/.osmedeus/workspaces/duckduckgo.com/fingerprint/duckduckgo.com-technologies.txt")
//
//	if !utils.FileExists("/Users/j3ssie/.osmedeus/workspaces/duckduckgo.com/fingerprint/duckduckgo.com-technologies.txt") {
//		t.WarnF("Error CleanWebanalyze")
//	}
//}

//func TestCleanSWebanalyze(t *testing.T) {
//    CleanSWebanalyze("/tmp/mmm", "/tmp/technologies.txt")
//    if !utils.FileExists("/tmp/technologies.txt") {
//        t.WarnF("Error CleanSWebanalyze")
//    }
//}
