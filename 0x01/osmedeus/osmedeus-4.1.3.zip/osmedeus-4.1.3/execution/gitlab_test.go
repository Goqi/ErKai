package execution

import (
	"testing"
)

func TestGitAuth(t *testing.T) {
	GitAuthSample()
}
