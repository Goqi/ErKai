package execution

import (
	"testing"
)

func TestListProcess(t *testing.T) {
	ListAllOsmedeusProcess()
}
