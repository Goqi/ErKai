package main

import "github.com/yhy0/Jie/cmd"

/**
  @author: yhy
  @since: 2023/1/27
  @desc: //TODO
**/

func main() {
	cmd.RunApp()
}
