cd $HOME/MyWork/nuclei-templates
git fetch origin master
git checkout 51pwn
git merge origin/master
