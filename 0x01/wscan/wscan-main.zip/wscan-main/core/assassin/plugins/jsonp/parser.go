/**
* @Author: shaochuyu
* @Date: 5/7/2022 11:30
 */
package jsonp

type JSONPParser struct {
}

func (*JSONPParser) Parse() {

}
func (*JSONPParser) recursiveExp() {

}
func (*JSONPParser) recursiveObj() {

}
