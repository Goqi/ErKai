/**
2 * @Author: shaochuyu
3 * @Date: 9/8/22
4 */

package http

import "net/http"

type Transport struct {
	*http.Transport
}
