/**
2 * @Author: shaochuyu
3 * @Date: 9/4/22
4 */

package http

//File: utils.go
//	init0 Lines: 19 to 57 (38)
//	CloneHeader Lines: 57 to 71 (14)
//	IsStaticURL Lines: 71 to 80 (9)
//	IsNeededResource Lines: 80 to 106 (26)
//	ReadCompressBody Lines: 106 to 145 (39)
//	GetTextContent Lines: 145 to 183 (38)
//	GetTextContentfunc1 Lines: 149 to 155 (6)
//	IsMeaninglessCookieKey Lines: 183 to 189 (6)
