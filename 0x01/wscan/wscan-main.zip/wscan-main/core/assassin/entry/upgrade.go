/**
* @Author: shaochuyu
* @Date: 5/7/2022 11:30
 */
package entry

func upgradeAction() {

}

func upgrade() {

}

type UpdateConfig struct {
	Disable bool `json:"disable" yaml:"disable"`
}
