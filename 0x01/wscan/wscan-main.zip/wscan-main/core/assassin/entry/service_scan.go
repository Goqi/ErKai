/**
* @Author: shaochuyu
* @Date: 5/7/2022 11:30
 */
package entry

func serviceScanAction() {

	// call getServiceFitter
}

func getServiceFitter() {
	// aTargettcNew ; "targettc_new
	// aTargetFile ; "target-file"
	// TargetCanTBeEm ; "target can't be empty"
}
