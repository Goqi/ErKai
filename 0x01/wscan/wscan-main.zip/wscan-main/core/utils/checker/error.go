/**
* @Author: shaochuyu
* @Date: 5/7/2022 11:30
 */
package checker

import "github.com/google/cel-go/common"

type typeErrors struct {
	*common.Errors
}
