package core

const (
	CLIName = "gospider"
	AUTHOR  = "@thebl4ckturtle & @j3ssiejjj"
	VERSION = "v1.1.6"
)
