Loot
=====

Client loot command implementations

