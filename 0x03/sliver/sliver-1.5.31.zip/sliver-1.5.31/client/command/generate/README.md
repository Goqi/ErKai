Generate
========

Implements command related to implant generation such as `generate`, `regenerate`, `profiles`, etc.

