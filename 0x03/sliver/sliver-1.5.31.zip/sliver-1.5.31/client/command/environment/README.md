Environment
===========

Contains command implementations for manipulating remote environment variables.
