Task Runner
============

This package is the shellcode executors, we just call them "tasks" just in case something leaks through the obfuscator. It has nothing to do with other "tasks" in Sliver, e..g. BeaconTasks

