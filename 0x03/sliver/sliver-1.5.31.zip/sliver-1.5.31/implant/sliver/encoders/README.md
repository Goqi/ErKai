Encoders
========

These are the implant-side encoders, almost all of the code is shared with `server/encoders` but there are a few small differences.

The unit tests for this package are in `server/encoders` (which imports this pkg).

