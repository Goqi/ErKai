// Merlin is a post-exploitation command and control framework.
// This file is part of Merlin.
// Copyright (C) 2022  Russel Van Tuyl

// Merlin is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// any later version.

// Merlin is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with Merlin.  If not, see <http://www.gnu.org/licenses/>.

package core

import "sync"

// Global Variables

// Verbose indicates if the agent should write messages to STDOUT
var Verbose = false

// Debug is used to troubleshoot problems and results in very detailed information being displayed on STDOUT
var Debug = false

// Version is the Merlin Agent's version number
var Version = "1.5.0"

// Mutex is used to ensure exclusive access to STDOUT & STDERR
var Mutex = &sync.Mutex{}
