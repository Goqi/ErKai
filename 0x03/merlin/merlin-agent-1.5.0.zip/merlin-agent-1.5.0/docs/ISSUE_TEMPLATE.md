### Prerequisite

* [ ] I have searched the opened & _closed_ [issues](https://github.com/Ne0nd0g/merlin-agent/issues)
* [ ] I have searched the [WIKI](https://merlin-c2.readthedocs.io/en/latest/index.html) and its [FAQ](https://merlin-c2.readthedocs.io/en/latest/quickStart/faq.html) page

### Environment Data

* Merlin Version:
* Merlin Build:
* Go Version:
* GOPATH Environment Variable:
* GOROOT Environment Variable:
* Operating System:

### Expected Behavior

### Actual Behavior

### Steps to Reproduce Behavior

### Misc Information
