package get

func UdpProtocol(host string, port int, timeout int) ([]byte, error) {
	return make([]byte, 256), nil
}
