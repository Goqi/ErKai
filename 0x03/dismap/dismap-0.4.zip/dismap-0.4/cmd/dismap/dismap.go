package main

/*
_____________
______  /__(_)_____________ _________ ________
_  __  /__  /__  ___/_  __ `__ \  __ `/__  __ \
/ /_/ / _  / _(__  )_  / / / / / /_/ /__  /_/ /
\__,_/  /_/  /____/ /_/ /_/ /_/\__,_/ _  .___/
                                        /_/
  author: zhzyker && Nemophllist
  from: https://github.com/zhzyker/dismap
*/

import (
	"github.com/zhzyker/dismap/internal"
)

func main() {
	internal.DisMap()
}
