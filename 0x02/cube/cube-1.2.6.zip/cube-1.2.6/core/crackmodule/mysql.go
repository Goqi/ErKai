package crackmodule

import (
	"cube/config"
	"database/sql"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
	"strings"
)

type Mysql struct {
	*Crack
}

func (m Mysql) CrackName() string {
	return "mysql"
}

func (m Mysql) CrackPort() string {
	return "3306"
}

func (m Mysql) CrackAuthUser() []string {
	return []string{"root", "mysql"}
}

func (m Mysql) CrackAuthPass() []string {
	return config.PASSWORDS
}

func (m Mysql) IsMutex() bool {
	return false
}

func (m Mysql) CrackPortCheck() bool {
	return true
}

func (m Mysql) Exec() CrackResult {
	result := CrackResult{Crack: *m.Crack, Result: false, Err: nil}

	dataSourceName := fmt.Sprintf("%v:%v@tcp(%v:%v)/mysql?charset=utf8&timeout=%v", m.Auth.User, m.Auth.Password, m.Ip, m.Port, config.TcpConnTimeout)
	db, err := sql.Open("mysql", dataSourceName)
	if err != nil {
		return result
	}
	err = db.Ping()
	if err != nil {
		return result
	}
	rows, err := db.Query("select @@version, @@version_compile_os, @@version_compile_machine, @@secure_file_priv;")
	if err != nil {
		return result
	}
	cols, _ := rows.Columns()
	for rows.Next() {
		err := rows.Scan(&cols[0], &cols[1], &cols[2], &cols[3])
		if err != nil {
			return result
		}
		result.Extra = fmt.Sprintf("OS=%s Version=%s Arch=%s File_Priv=%s\t", strings.Split(cols[1], "-")[0], cols[0], cols[2], cols[3])
		result.Result = true
	}
	return result
}

func init() {
	AddCrackKeys("mysql")
}
