package crackmodule

type CrackReport struct {
	*CrackResult
}
