package main

import "cube/cli/cmd"

func main() {
	cmd.Execute()
}
