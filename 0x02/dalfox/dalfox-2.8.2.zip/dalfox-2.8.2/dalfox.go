/*
Code by @hahwul
Happy hacking :D
*/
package main

import "github.com/hahwul/dalfox/v2/cmd"

func main() {
	cmd.Execute()
}
