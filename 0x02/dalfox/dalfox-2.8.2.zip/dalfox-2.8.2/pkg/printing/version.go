package printing

// VERSION is version of dalfox
const VERSION = "v2.8.2"
