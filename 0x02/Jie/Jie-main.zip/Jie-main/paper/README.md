
> 提醒自己每个漏洞检测优化时，最好都写一篇文章


# 漏洞专项检测文章

## 越权

https://www.gem-love.com/2023/01/26/%E6%B0%B4%E5%B9%B3%E8%B6%8A%E6%9D%83%E6%8C%96%E6%8E%98%E6%8A%80%E5%B7%A7%E4%B8%8E%E8%87%AA%E5%8A%A8%E5%8C%96%E8%B6%8A%E6%9D%83%E6%BC%8F%E6%B4%9E%E6%A3%80%E6%B5%8B/#undefined
