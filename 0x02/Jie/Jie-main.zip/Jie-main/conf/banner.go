package conf

/**
  @author: yhy
  @since: 2023/1/27
  @desc: //TODO
**/

var Banner = `
     ██╗██╗███████╗
     ██║██║██╔════╝
     ██║██║█████╗  
██   ██║██║██╔══╝  
╚█████╔╝██║███████╗
 ╚════╝ ╚═╝╚══════╝
                   
`

const Website = "https://github.com/yhy0/Jie"

const Version = "0.1.0"
