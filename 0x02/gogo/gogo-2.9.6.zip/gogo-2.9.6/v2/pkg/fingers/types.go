package fingers

const (
	None = iota
	ACTIVE
	ICO
	NOTFOUND
	GUESS
)

const (
	INFO int = iota + 1
	MEDIUM
	HIGH
	CRITICAL
)
