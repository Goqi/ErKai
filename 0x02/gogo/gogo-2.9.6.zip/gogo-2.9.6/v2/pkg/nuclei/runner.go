package nuclei

//import "gogo/src/nuclei/templates"
//
//func processTemplate(url string, template *templates.Template)bool{
//	template.Executor.Execute(url)
//	return false
//}
