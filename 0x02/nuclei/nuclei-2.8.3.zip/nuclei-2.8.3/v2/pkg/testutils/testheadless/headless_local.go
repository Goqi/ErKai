//go:build headless_local

package testheadless

// HeadlessLocal determines if local headless chrome should be used in tests
const HeadlessLocal = true
