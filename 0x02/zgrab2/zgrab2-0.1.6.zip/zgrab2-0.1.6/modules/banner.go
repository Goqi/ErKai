package modules

import (
	"github.com/zmap/zgrab2/modules/banner"
)

func init() {
	banner.RegisterModule()
}
