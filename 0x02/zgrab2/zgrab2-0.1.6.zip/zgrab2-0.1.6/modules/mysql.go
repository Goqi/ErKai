package modules

import "github.com/zmap/zgrab2/modules/mysql"

func init() {
	mysql.RegisterModule()
}
