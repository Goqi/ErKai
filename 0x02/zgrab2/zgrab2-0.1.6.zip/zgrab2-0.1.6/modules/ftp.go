package modules

import "github.com/zmap/zgrab2/modules/ftp"

func init() {
	ftp.RegisterModule()
}
