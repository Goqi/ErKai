package modules

import "github.com/zmap/zgrab2/modules/smtp"

func init() {
	smtp.RegisterModule()
}
