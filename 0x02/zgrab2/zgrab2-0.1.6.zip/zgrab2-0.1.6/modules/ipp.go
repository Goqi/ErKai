package modules

import "github.com/zmap/zgrab2/modules/ipp"

func init() {
	ipp.RegisterModule()
}
