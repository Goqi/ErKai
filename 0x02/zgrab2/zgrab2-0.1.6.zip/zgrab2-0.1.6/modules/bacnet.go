package modules

import "github.com/zmap/zgrab2/modules/bacnet"

func init() {
	bacnet.RegisterModule()
}
