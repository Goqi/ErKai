package portfinger

type Options struct {
	Proxy  string
	Debug  bool
	Host   string
	Ports  string
	Thread int
}
