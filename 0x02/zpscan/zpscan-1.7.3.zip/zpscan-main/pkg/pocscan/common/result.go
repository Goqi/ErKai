package common

type Result struct {
	Target     string
	PocTag     string
	Source     string
	Level      string
	PocName    string
	Extractors string
}
