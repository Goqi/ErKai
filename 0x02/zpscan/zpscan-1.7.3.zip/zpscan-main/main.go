package main

import (
	"github.com/niudaii/zpscan/cmd"
	_ "github.com/projectdiscovery/fdmax/autofdmax"
)

func main() {
	cmd.Execute()
}
