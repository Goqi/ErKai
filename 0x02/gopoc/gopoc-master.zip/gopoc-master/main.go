package main

import "gopoc/cmd"

func main() {
	cmd.Execute()
}
